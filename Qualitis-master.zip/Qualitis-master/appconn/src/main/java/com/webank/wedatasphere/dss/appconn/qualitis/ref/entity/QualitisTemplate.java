package com.webank.wedatasphere.dss.appconn.qualitis.ref.entity;

/**
 * @author leebai
 * @date 2022/5/23 20:45
 */
public class QualitisTemplate {

    Integer template_id;

    String template_name;

}
