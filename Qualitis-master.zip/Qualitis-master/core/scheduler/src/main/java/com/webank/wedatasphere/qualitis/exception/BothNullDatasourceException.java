package com.webank.wedatasphere.qualitis.exception;

/**
 * @author allenzhou@webank.com
 * @date 2021/7/14 1:13
 */
public class BothNullDatasourceException extends Exception {

    public BothNullDatasourceException(String message) {
        super(message);
    }
}
