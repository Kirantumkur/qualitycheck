package com.webank.wedatasphere.qualitis.exception;

/**
 * @author allenzhou@webank.com
 * @date 2021/7/14 1:14
 */
public class LeftNullDatasourceException extends Exception {

    public LeftNullDatasourceException(String message) {
        super(message);
    }
}
