package com.webank.wedatasphere.qualitis.exception;

/**
 * @author howeye
 */
public class NoSuchDataBaseException extends Exception {

}
