package com.webank.wedatasphere.qualitis.exception;

/**
 * @author allenzhou@webank.com
 * @date 2021/7/14 1:14
 */
public class NullDatasourceException extends Exception {

    public NullDatasourceException(String message) {
        super(message);
    }
}
