package com.webank.wedatasphere.qualitis.exception;

/**
 * @author allenzhou@webank.com
 * @date 2021/7/14 1:14
 */
public class RightNullDatasourceException extends Exception {

    public RightNullDatasourceException(String message) {
        super(message);
    }
}
