package com.webank.wedatasphere.qualitis.exception;

/**
 * @author howeye
 */
public class SystemConfigException extends Exception {

    public SystemConfigException(String message) {
        super(message);
    }
}
