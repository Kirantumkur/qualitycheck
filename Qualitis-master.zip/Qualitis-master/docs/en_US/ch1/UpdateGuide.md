# Update Guide

## update from 0.5.0 to 0.6.0
Download code of 0.6.0 version.

Execute the following code below:
```
mysql -u {USERNAME} -p {PASSWORD} -h {IP} --default-character-set=utf8
source conf/database/update/update_0.5.0-0.6.0.sql
```