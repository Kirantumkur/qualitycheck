/*
用于分页
*/
const sizeList = [5, 10, 15, 20, 50, 100];


export {
    sizeList
}