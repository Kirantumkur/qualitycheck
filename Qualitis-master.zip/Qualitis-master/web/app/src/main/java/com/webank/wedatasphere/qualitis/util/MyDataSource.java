package com.webank.wedatasphere.qualitis.util;

import com.zaxxer.hikari.HikariDataSource;

/**
 * @author allenzhou
 */
public class MyDataSource extends HikariDataSource {
}
