package com.webank.wedatasphere.qualitis.request;

/**
 * @author allenzhou@webank.com
 * @date 2021/5/17 17:00
 */
public class UploadRuleMetricRequest {

}
