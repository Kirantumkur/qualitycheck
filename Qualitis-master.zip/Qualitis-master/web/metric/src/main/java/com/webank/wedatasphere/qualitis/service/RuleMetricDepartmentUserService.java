package com.webank.wedatasphere.qualitis.service;

/**
 * @author allenzhou@webank.com
 * @date 2021/2/22 16:19
 */
public interface RuleMetricDepartmentUserService {

}
