package com.webank.wedatasphere.qualitis.service.impl;

import com.webank.wedatasphere.qualitis.service.RuleMetricDepartmentUserService;

/**
 * @author allenzhou@webank.com
 * @date 2021/2/22 16:25
 */
public class RuleMetricDepartmentUserServiceImpl implements RuleMetricDepartmentUserService {

}
